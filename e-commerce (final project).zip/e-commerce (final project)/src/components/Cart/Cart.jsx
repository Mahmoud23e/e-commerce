import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { useContext, useEffect } from "react";
import { Bars } from "react-loader-spinner";
import { cartContextt } from "../../Context/CartContext";
import toast from "react-hot-toast";
import { Link } from "react-router-dom";

export default function Cart() {
  const {
    numOfCartitems,
    allproducts,
    totalcartprics,
    setnumOfCartitems,
    updatecount,
    count,
    setcount,
    settotalcartprics,
    setallproducts,
    getcartproducts,
    isloading,
    deleteproduct,
    clearcart,
  } = useContext(cartContextt);
  useEffect(() => {
    getcartproducts();
  }, []);

  function handleupdatecount(product_id, newcount) {
    updatecount(product_id, newcount);
  }

  async function handledelete(id) {
    const res = await deleteproduct(id);
    if (res) {
      toast.success("product deleted ");
    } else {
      toast.error("product deleted error ");
    }
  }

  //   useQuery({
  //     queryKey: "uptatedproduct",
  //     queryFn: handleupatecount,
  //   });

  //   const { data, isLoading, isError, isSuccess } = useQuery({
  //     queryKey: ["cartproducts"],
  //     queryFn: getcartproducts,
  //   });
  //   console.log(data);

  //   //   if (isSuccess) {
  //   //     setallproducts(data.data.data.products);
  //   //     setnumOfCartitems(data.data.numOfCartItems);
  //   //     settotalcartprics(data.data.data.totalCartPrice);
  //   //     console.log("state updated");
  //   //   }

  //   if (isLoading) {
  //     return (
  //       <>
  //         <div className=" flex justify-center items-center h-screen">
  //           <Bars
  //             height="80"
  //             width="80"
  //             color="#4fa94d"
  //             ariaLabel="bars-loading"
  //             wrapperStyle={{}}
  //             wrapperClass=""
  //             visible={true}
  //           />
  //         </div>
  //         ;
  //       </>
  //     );
  //   }

  return (
    <>
      <div className=" bg-[#eee] mt-[200px] container mx-auto p-7 ">
        <div className=" flex justify-between items-center ">
          <h2 className="text-[35px]">cart shop</h2>
          {totalcartprics != 0 ? (
            <Link to="/payment">
              <button className=" bg-blue-600 p-3 text-[20px]  text-white font-semibold rounded-[10px] ">
                check out
              </button>
            </Link>
          ) : (
            ""
          )}
        </div>
        <div className=" flex justify-between items-center mt-[20px] ">
          <h2 className="text-[25px]">
            total price:
            <span className=" ms-1 text-green-500 font-semibold text-[20px]">
              {/* {data.data.data.totalCartPrice} */}
              {totalcartprics}
            </span>
          </h2>
          <button className=" font-semibold text-[20px]">
            total number of items:
            <span className=" text-green-500 text-[20px]">
              {numOfCartitems}
            </span>
          </button>
        </div>

        {isloading ? (
          <>
            <div className=" flex justify-center items-center h-screen">
              <Bars
                height="80"
                width="80"
                color="#4fa94d"
                ariaLabel="bars-loading"
                wrapperStyle={{}}
                wrapperClass=""
                visible={true}
              />
            </div>
            ;
          </>
        ) : (
          allproducts?.map((product) => (
            <>
              <div className="grid md:grid-cols-2 gap-1 mt-4">
                <div className="left flex items-center">
                  <div className="photo  md:w-1/4 ">
                    <img
                      src={product.product.imageCover}
                      className="w-full"
                      alt=""
                    />
                  </div>
                  <div className="details md:w-[70%] ms-4">
                    <p> {product.product.title}</p>
                    <p>{product.price} EGP</p>
                    <div
                      className="cursor-pointer w-fit mt-2 "
                      onClick={() => handledelete(product.product._id)}
                    >
                      <i className="fa-solid fa-trash me-1 text-red-600 "></i>
                      <span className="text-red-600 ">Remove</span>
                    </div>
                  </div>
                </div>
                <div className="right  flex justify-end items-center pe-6">
                  <i
                    onClick={() =>
                      handleupdatecount(product.product._id, product.count + 1)
                    }
                    className="fa-solid fa-plus p-2 border-[2px] rounded-md border-green-400  cursor-pointer"
                  ></i>
                  <span className=" mx-4">{product.count}</span>
                  <i
                    onClick={() =>
                      handleupdatecount(product.product._id, product.count - 1)
                    }
                    className="fa-solid fa-minus p-2 border-[2px] rounded-md border-green-400 cursor-pointer"
                  ></i>
                </div>
              </div>
            </>
          ))
        )}
        <div className=" w-full h-[1px] bg-gray-300 mt-2 rounded-md "></div>
        <div onClick={clearcart} className="flex justify-center  ">
          <p className="w-fit text-[20px] hover:bg-green-400 hover:text-white transition duration-300   mt-4  p-2 border-[2px] rounded-md border-green-400  cursor-pointer">
            Clear Your Cart
          </p>
        </div>
      </div>
    </>
  );
}
