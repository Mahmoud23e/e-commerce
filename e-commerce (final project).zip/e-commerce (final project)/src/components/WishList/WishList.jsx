import { useContext, useEffect } from "react";
import { wishlistcontext } from "../../Context/wishlistcontext";
import toast from "react-hot-toast";
import { Bars } from "react-loader-spinner";
import { cartContextt } from "../../Context/CartContext";

export default function WishList() {
  const {
    allwishlistproducts,
    getwishlistproducts,
    deletewishlistproduct,
    isloading,
  } = useContext(wishlistcontext);

  const { addproductTocart } = useContext(cartContextt);

  async function handleaddproduct(id) {
    deletewishlistproduct(id);

    const resflag = await addproductTocart(id);

    console.log("resflag", resflag);

    if (resflag) {
      toast.success("product added successfully", {
        position: "top-right",
        duration: 3000,
      });
    } else {
      toast.error("something went wrong", {
        position: "top-right",
        duration: 3000,
      });
    }
  }

  async function handledeletefromwishlist(id) {
    const res = await deletewishlistproduct(id);
    if (res) {
      toast.success("product deleted ");
    } else {
      toast.error("product deleted error ");
    }
  }
  useEffect(() => {
    getwishlistproducts();
  }, []);

  return (
    <>
      <div className=" bg-[#eee] mt-[200px] container mx-auto p-7 ">
        <div className=" flex justify-between items-center ">
          <h2 className="text-[35px]">My wish List</h2>
        </div>

        {isloading ? (
          <>
            <div className=" flex justify-center items-center h-screen">
              <Bars
                height="80"
                width="80"
                color="#4fa94d"
                ariaLabel="bars-loading"
                wrapperStyle={{}}
                wrapperClass=""
                visible={true}
              />
            </div>
            ;
          </>
        ) : (
          <>
            {allwishlistproducts?.map((product) => (
              <>
                <div className="grid md:grid-cols-2 gap-1 mt-4">
                  <div className="left flex flex-col  md:flex-row  items-center">
                    <div className="photo  md:w-1/4 ">
                      <img src={product.imageCover} className="w-full" alt="" />
                    </div>
                    <div className="details md:w-[70%] flex flex-row gap-10 mt-3 md:flex md:flex-col md:mt-0 md:gap-0  ms-4">
                      <div>
                        <p> {product.title}</p>
                        <p>{product.price} EGP</p>
                      </div>
                      <div
                        onClick={() => handledeletefromwishlist(product._id)}
                        className="cursor-pointer w-fit mt-2 "
                      >
                        <i className="fa-solid fa-trash me-1 text-red-600 "></i>
                        <span className="text-red-600 ">Remove</span>
                      </div>
                    </div>
                  </div>
                  <div
                    onClick={() => {
                      handleaddproduct(product._id);
                    }}
                    className="right flex justify-end items-center "
                  >
                    <button className="p-3 border-[1px] border-green-500 rounded-md hover:bg-green-500 hover:text-white  transition duration-300">
                      Add to Cart
                    </button>
                  </div>
                </div>
              </>
            ))}
          </>
        )}

        <div className=" w-full h-[1px] bg-gray-300 mt-2 rounded-md "></div>
      </div>
    </>
  );
}
