import axios from "axios";
import { useFormik } from "formik";
import { useContext, useState } from "react";
import { ColorRing } from "react-loader-spinner";
import { useNavigate } from "react-router-dom";
import * as yup from "yup";
import { cartContextt } from "../../Context/CartContext";
import toast from "react-hot-toast";

export default function Payment() {
  const [iserror, setiserror] = useState(null);
  const [isloading, setisloading] = useState(false);
  const [isSuccess, setisSuccess] = useState(false);
  const [isonline, setisonline] = useState(false);
  const navigat = useNavigate();
  const { cartidforpayment, totalcartprics } = useContext(cartContextt);

  function Detectandcall(values) {
    if (isonline) {
      onlinepayment(values);
    } else {
      creatcashorder(values);
    }
  }

  function onlinepayment(values) {
    setisloading(true);

    console.log(values);
    const backendbody = {
      shippingAddress: values,
    };

    axios
      .post(
        `https://ecommerce.routemisr.com/api/v1/orders/checkout-session/${cartidforpayment}`,
        backendbody,
        {
          headers: {
            token: localStorage.getItem("tkn"),
          },
          params: {
            url: "http://localhost:5174",
          },
        }
      )
      .then((res) => {
        console.log("res", res.data);
        setisloading(false);
        toast.success("successful payment");
        window.open(res.data.session.url, "_self");
      })
      .catch((err) => {
        console.log("err", err);
        toast.error("some thing wrong");
        setisloading(false);
      });
  }

  ////////////////////////////////////////////////
  ////////////////////////////////////////////////
  ////////////////////////////////////////////////

  function creatcashorder(values) {
    setisloading(true);

    console.log(values);
    const backendbody = {
      shippingAddress: values,
    };

    axios
      .post(
        `https://ecommerce.routemisr.com/api/v1/orders/${cartidforpayment}`,
        backendbody,
        {
          headers: {
            token: localStorage.getItem("tkn"),
          },
        }
      )
      .then((res) => {
        console.log("res", res.data);
        setisloading(false);
        navigat("/cart");
      })
      .catch((err) => {
        console.log("err", err);
        toast.error("some thing wrong");
        setisloading(false);
        navigat("/cart");
      });
  }

  const paymentformik = useFormik({
    initialValues: {
      details: "",
      city: "",
      phone: "",
    },
    onSubmit: Detectandcall,
    validationSchema: yup.object().shape({
      city: yup
        .string()
        .required("city name is required")
        .matches(/^[a-zA-Z]+$/, "numbers and special characters not allowed"),
      details: yup
        .string()
        .required("details is required")
        .matches(/^[a-zA-Z0-9]+$/, "please enter a valid email"),
      phone: yup
        .string()
        .required("phone is required")
        .matches(/^(\+20|0)?1[0125][0-9]{8}$/, "invalid phone number"),
    }),
  });
  return (
    <>
      {totalcartprics != 0 ? (
        <div className=" container mx-auto p-7">
          <form
            onSubmit={paymentformik.handleSubmit}
            className=" container mx-auto p-4 text-black mt-20  "
          >
            <div className="relative z-0 w-full mb-5 group">
              <input
                type="textdetails"
                name="details"
                onBlur={paymentformik.handleBlur}
                onChange={paymentformik.handleChange}
                value={paymentformik.values.details}
                id="details"
                className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-black dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                placeholder=" "
                required
              />
              <label
                htmlFor="details"
                className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
              >
                details:
              </label>
            </div>
            {paymentformik.errors.details && paymentformik.touched.details ? (
              <div
                className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-red-400 text-white"
                role="alert"
              >
                <svg
                  className="flex-shrink-0 inline w-4 h-4 me-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                </svg>
                <span className="sr-only">Info</span>
                <div>{paymentformik.errors.details}</div>
              </div>
            ) : (
              ""
            )}

            {/* /////////////////////////// */}
            {/* /////////////////////////// */}
            <div className="relative z-0 w-full mb-5 group">
              <input
                type="text"
                name="city"
                onBlur={paymentformik.handleBlur}
                onChange={paymentformik.handleChange}
                value={paymentformik.values.city}
                id="city"
                className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-black dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                placeholder=" "
                required
              />
              <label
                htmlFor="city"
                className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
              >
                City:
              </label>
            </div>
            {paymentformik.errors.city && paymentformik.touched.city ? (
              <div
                className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-red-400 text-white"
                role="alert"
              >
                <svg
                  className="flex-shrink-0 inline w-4 h-4 me-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                </svg>
                <span className="sr-only">Info</span>
                <div>{paymentformik.errors.city}</div>
              </div>
            ) : (
              ""
            )}
            {/* /////////////////////////// */}
            {/* /////////////////////////// */}

            <div className="relative z-0 w-full mb-5 group">
              <input
                type="phone"
                name="phone"
                onBlur={paymentformik.handleBlur}
                onChange={paymentformik.handleChange}
                value={paymentformik.values.phone}
                id="phone"
                className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-black dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                placeholder=" "
                required
              />
              <label
                htmlFor="phone"
                className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
              >
                Phone:
              </label>
            </div>
            {paymentformik.errors.phone && paymentformik.touched.phone ? (
              <div
                className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-red-400 text-white"
                role="alert"
              >
                <svg
                  className="flex-shrink-0 inline w-4 h-4 me-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                </svg>
                <span className="sr-only">Info</span>
                <div>{paymentformik.errors.phone}</div>
              </div>
            ) : (
              ""
            )}

            {iserror ? (
              <div
                className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-red-400 text-white"
                role="alert"
              >
                <svg
                  className="flex-shrink-0 inline w-4 h-4 me-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                </svg>
                <span className="sr-only">Info</span>
                <div>{iserror}</div>
              </div>
            ) : (
              ""
            )}
            {isSuccess ? (
              <div
                className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-green-400 text-white"
                role="alert"
              >
                <svg
                  className="flex-shrink-0 inline w-4 h-4 me-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                </svg>
                <span className="sr-only">Info</span>
                <div>welcome</div>
              </div>
            ) : (
              ""
            )}

            <div className=" flex  gap-2">
              <button
                onClick={() => setisonline(false)}
                type="submit"
                className=" flex items-center text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto  px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
              >
                {isloading ? (
                  <ColorRing
                    visible={true}
                    height="30"
                    width="30"
                    ariaLabel="color-ring-loading"
                    wrapperStyle={{}}
                    wrapperClass="color-ring-wrapper"
                    colors={["#fff", "#fff", "#fff", "#fff", "#fff"]}
                  />
                ) : (
                  " Cash Order"
                )}
              </button>
              <button
                onClick={() => setisonline(true)}
                type="submit"
                className=" flex items-center text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto  px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
              >
                {isloading ? (
                  <ColorRing
                    visible={true}
                    height="30"
                    width="30"
                    ariaLabel="color-ring-loading"
                    wrapperStyle={{}}
                    wrapperClass="color-ring-wrapper"
                    colors={["#fff", "#fff", "#fff", "#fff", "#fff"]}
                  />
                ) : (
                  " pay now"
                )}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <>
          <div className=" h-screen bg-green-500 flex justify-center items-center ">
            <p className=" text-white text-[100px] font-bold text-center">
              error 404 please go back to home
            </p>
          </div>
        </>
      )}
    </>
  );
}
