import axios from "axios";

export default function Allorders() {
  function getUserOrders() {
    axios.get("");
  }
  return;

  // <>
  //   <div className="left flex items-center">
  //     <div className="photo  md:w-1/4 ">
  //       <img src={product.product.imageCover} className="w-full" alt="" />
  //     </div>
  //     <div className="details md:w-[70%] ms-4">
  //       <p> {product.product.title}</p>
  //       <p>{product.price} EGP</p>
  //       <div
  //         className="cursor-pointer w-fit mt-2 "
  //         onClick={() => handledelete(product.product._id)}
  //       >
  //         <i className="fa-solid fa-trash me-1 text-red-600 "></i>
  //         <span className="text-red-600 ">Remove</span>
  //       </div>
  //     </div>
  //   </div>
  // </>
  //   );
}
