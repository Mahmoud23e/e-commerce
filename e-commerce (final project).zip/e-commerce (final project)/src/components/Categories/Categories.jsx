import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { Bars } from "react-loader-spinner";

export default function Categories() {
  function getAllCategories() {
    return axios.get("https://ecommerce.routemisr.com/api/v1/categories");
  }

  const { data, isError, isLoading } = useQuery({
    queryKey: "getAllCategories",
    queryFn: getAllCategories,
  });

  if (isLoading) {
    return (
      <>
        <div className=" flex justify-center items-center h-screen">
          <Bars
            height="80"
            width="80"
            color="#4fa94d"
            ariaLabel="bars-loading"
            wrapperStyle={{}}
            wrapperClass=""
            visible={true}
          />
        </div>
      </>
    );
  }
  if (isError) {
    return (
      <>
        <h2>error</h2>
      </>
    );
  }

  return (
    <>
      <div className="input flex justify-center container   mx-auto mt-[150px]">
        <input
          type="search"
          className=" border-2    w-3/4 border-gray-300  rounded-md p-2  "
          placeholder="search"
        />
      </div>
      <div className=" grid md:grid-cols-3 lg:grid-cols-4 container mx-auto mt-[50px]  ">
        {data.data.data.map((product) => (
          <div
            key={product._id}
            className="text-center border-[2px] m-2  text-black transition ease-in-out duration-500 cursor-pointer   rounded-md mx-2  hover:shadow-[0px_1px_13px_rgba(22,163,74)] group overflow-hidden "
          >
            <div>
              <img
                src={product.image}
                className=" w-full h-[300px] group-hover:scale-[1.2] transition duration-700 "
                alt={product.name}
              />
            </div>
            <p className=" bg-white text-black p-4 font-semibold text-[25px]  relative z-[9999] group-hover:text-green-500 transition duration-500">
              {product.name}
            </p>
          </div>
        ))}
      </div>
    </>
  );
}
