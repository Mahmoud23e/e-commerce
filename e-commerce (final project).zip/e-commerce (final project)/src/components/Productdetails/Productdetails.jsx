import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { useContext } from "react";
import { Bars } from "react-loader-spinner";
import { useParams } from "react-router-dom";
import Slider from "react-slick";
import { cartContextt } from "../../Context/CartContext";
import toast from "react-hot-toast";

export default function Productdetails() {
  const { numOfCartitems, addproductTocart } = useContext(cartContextt);

  async function handleaddproduct(id) {
    const resflag = await addproductTocart(id);
    console.log("resflag", resflag);

    if (resflag) {
      toast.success("product added successfully", {
        position: "top-right",
        duration: 3000,
      });
    } else {
      toast.error("something went wrong", {
        position: "top-right",
        duration: 3000,
      });
    }
  }

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    autoplay: true,
  };
  const { id } = useParams();
  function Getproductdetails() {
    return axios.get(`https://ecommerce.routemisr.com/api/v1/products/${id}`);
  }
  const { isError, data, isLoading } = useQuery({
    queryKey: ["productdetails", id],
    queryFn: Getproductdetails,
  });

  if (isLoading) {
    return (
      <>
        <div className=" flex justify-center items-center h-screen">
          <Bars
            height="80"
            width="80"
            color="#4fa94d"
            ariaLabel="bars-loading"
            wrapperStyle={{}}
            wrapperClass=""
            visible={true}
          />
        </div>
        ;
      </>
    );
  }
  if (isError) {
    return (
      <>
        <h1>error;</h1>
      </>
    );
  }
  let objectdetails = data.data.data;

  return (
    <>
      <div className="mt-[150px] flex justify-center items-center container mx-auto">
        <div className="left w-1/4 ">
          <Slider {...settings} className="mt-[40px] cursor-grab  ">
            <div>
              <img
                className="w-full"
                src={objectdetails.images[0]}
                alt={objectdetails.title}
              />
            </div>
            <div>
              <img
                className="w-full"
                src={objectdetails.images[1]}
                alt={objectdetails.title}
              />
            </div>
            <div>
              <img
                className="w-full"
                src={objectdetails.images[2]}
                alt={objectdetails.title}
              />
            </div>
          </Slider>
        </div>
        <div className="right w-[70%] flex flex-col ms-7 ps-4 ">
          <h2 className=" text-[40px] font-semibold">{objectdetails.title}</h2>
          <p>{objectdetails.description}</p>
          <span className=" mt-2">
            <span className=" font-bold ">Price:</span> {objectdetails.price}{" "}
            EGp
          </span>
          <div className="w-3/4 mx-auto flex  items-center">
            <button
              onClick={() => {
                handleaddproduct(objectdetails._id);
              }}
              className="bg-[#15cc2d] font-semibold text-white w-full rounded-md p-3 mx-auto mt-16 "
            >
              + Add
            </button>
            <div className="icons ms-6 flex flex-col justify-center items-center">
              <div className=" items-center flex ">
                <i className="fa-solid   fa-star text-yellow-300"></i>
                <span>{objectdetails.ratingsQuantity}</span>
              </div>
              <div className=" flex mt-5 items-center">
                <i className="fa-solid fa-heart text-[30px]"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
