import { Link, NavLink, useNavigate } from "react-router-dom";
import freshcartlogo from "../../assets/finalProject assets/images/freshcart-logo.svg";
import { useContext, useEffect } from "react";
import { authcontext } from "../../Context/AuthContext";
import { cartContextt } from "../../Context/CartContext";
import toast from "react-hot-toast";
import axios from "axios";

export default function Navbar() {
  const navigat = useNavigate();
  const { numOfCartitems, setnumOfCartitems, addproductTocart } =
    useContext(cartContextt);

  async function getcartproducts() {
    return axios
      .get("https://ecommerce.routemisr.com/api/v1/cart", {
        headers: {
          token: localStorage.getItem("tkn"),
        },
      })
      .then((res) => {
        setnumOfCartitems(res.data.numOfCartItems);

        return true;
      })
      .catch((error) => {
        console.log(error);
        return false;
      });
  }
  useEffect(() => {
    getcartproducts();
  }, []);

  function handlelogout() {
    localStorage.removeItem("tkn");
    settoken(null);
    navigat("/login");
  }
  // const { counter } = useContext(cartContextt);
  const { token, settoken } = useContext(authcontext);
  return (
    <>
      <div className=" bg-[#eee] p-3 fixed w-full z-[99] top-0 left-0 ">
        <div className="nav flex container mx-auto justify-between p-3   ">
          <div className="left flex items-center  gap-6 font-bold">
            <Link>
              <img src={freshcartlogo} alt="cart logo" />
            </Link>
            <ul className="flex ms-40 gap-5">
              {token ? (
                <>
                  <li>
                    <NavLink to="" className="pb-1">
                      Home
                    </NavLink>
                  </li>
                  <li>
                    <NavLink to="/products" className="pb-1">
                      products
                    </NavLink>
                  </li>

                  <li>
                    <NavLink to="/cart" className="pb-1">
                      cart
                    </NavLink>
                  </li>
                  <li>
                    <NavLink to="/wishlist" className="pb-1">
                      Wish list
                    </NavLink>
                  </li>
                  <li>
                    <NavLink to="/categories" className="pb-1">
                      categories
                    </NavLink>
                  </li>
                  <li>
                    <NavLink to="/brands" className="pb-1">
                      Brands
                    </NavLink>
                  </li>
                </>
              ) : null}
            </ul>
          </div>
          <div className="right flex items-center gap-5 font-bold">
            <ul className=" flex gap-5">
              {!token ? (
                <>
                  <li>
                    <NavLink to="/register" className="pb-1">
                      Register
                    </NavLink>
                  </li>
                  <li>
                    <NavLink to="/login" className="pb-1">
                      Login
                    </NavLink>
                  </li>
                </>
              ) : (
                <>
                  <Link to="cart">
                    <li>
                      <span className=" cursor-pointer relative">
                        <i className="fa-solid fa-cart-shopping text-[30px] hover:text-green-800 transition duration-400"></i>
                        <div className="   relative bg-green-800 text-white p-[12px] w-4 text-center flex items-center justify-center rounded-[5px] h-4 top-[-40px] right-[-20px]">
                          {numOfCartitems}
                        </div>
                      </span>
                    </li>
                  </Link>
                  <li>
                    <span className=" cursor-pointer " onClick={handlelogout}>
                      Logout
                    </span>
                  </li>
                </>
              )}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}
