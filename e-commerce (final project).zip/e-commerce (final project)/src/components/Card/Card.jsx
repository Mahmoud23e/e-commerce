// import { useContext } from "react";
import { useContext } from "react";
import { Link } from "react-router-dom";
import { cartContextt } from "../../Context/CartContext";
import toast from "react-hot-toast";
// import { cartContextt } from "../../Context/CartContext";
import { wishlistcontext } from "../../Context/wishlistcontext";
import { useState } from "react";

export default function Card({ product }) {
  const [heartcolor, setheartcolor] = useState(false);

  async function handleaddproduct(id) {
    // getcartproducts();
    const resflag = await addproductTocart(id);
    console.log("resflag", resflag);

    if (resflag) {
      toast.success("product added successfully", {
        position: "top-right",
        duration: 3000,
      });
    } else {
      toast.error("something went wrong", {
        position: "top-right",
        duration: 3000,
      });
    }
  }
  ////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  async function handleaddproductTowishlist(id) {
    setheartcolor(true);
    const resflag = await addProductToWishList(id);
    console.log("resflag", resflag);

    if (resflag) {
      toast.success("product added successfully to wish list", {
        position: "top-right",
        duration: 3000,
      });
    } else {
      toast.error("something went wrong", {
        position: "top-right",
        duration: 3000,
      });
    }
  }
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  const { numOfCartitems, addproductTocart, setnumOfCartitems } =
    useContext(cartContextt);
  const { addProductToWishList } = useContext(wishlistcontext);
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  return (
    <>
      <div
        key={product._id}
        className=" transition ease-in-out duration-500 cursor-pointer pb-[40px] pt-4 rounded-md mx-2 hover:shadow-[0px_1px_13px_rgba(22,163,74)]  group p-3"
      >
        <Link to={`/ProductDetails/${product._id}`}>
          <div className=" overflow-hidden">
            <img
              src={product.imageCover}
              className=" group-hover:scale-[1.2] transition duration-500 w-full"
              alt="title"
            />
          </div>
          <p className=" text-green-600 mb-2">{product.category.name}</p>
          <p className=" font-medium mb-2">{product.title}</p>
          <div className="flex justify-between align-center">
            <p>{product.price} EGp</p>
            <p>
              <i className="fa-solid fa-star text-yellow-300"></i>
              {product.ratingsAverage}
            </p>
          </div>
        </Link>
        <div className="btn   opacity-0  text-center relative mt-4 translate-y-52 group-hover:opacity-100 group-hover:translate-y-14  transition ease-in-out duration-[0.5s] ">
          <button
            onClick={() => {
              handleaddproduct(product._id);
            }}
            className=" relative z-50 py-2  w-3/4 text-white rounded-md hover:bg-green-800 transition duration-300  bg-[#48a248]"
          >
            + Add
          </button>
        </div>
        <div
          id={product._id}
          onClick={() => {
            handleaddproductTowishlist(product._id);
          }}
          className=" w-full flex justify-end  "
        >
          <i
            className={
              heartcolor
                ? "fa-solid fa-heart text-[30px] text-red-500"
                : "fa-solid fa-heart text-[30px] "
            }
          ></i>
        </div>
      </div>
    </>
  );
}
