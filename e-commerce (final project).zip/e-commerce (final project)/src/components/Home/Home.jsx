import axios from "axios";
import { Bars } from "react-loader-spinner";
import SimpleSlider from "../slikslider/slikslider";
import sliderimg1 from "../../assets/finalProject assets/images/XCM_Manual_1396328_4379575_Egypt_EG_BAU_GW_DC_SL_Bags_Wallets_379x304_1X._SY304_CB650636675_.jpg";
import sliderimg2 from "../../assets/finalProject assets/images/XCM_Manual_1533480_5305769_379x304_1X._SY304_CB616236518_.jpg";
import Categories from "../Categoryslider/Categoryslider";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { useContext, useState } from "react";
import { useFormik } from "formik";
import { cartContextt } from "../../Context/CartContext";
import toast from "react-hot-toast";
import { wishlistcontext } from "../../Context/wishlistcontext";
import Card from "../card/Card";

export default function Products() {
  async function handleaddproduct(id) {
    // getcartproducts();
    const resflag = await addproductTocart(id);
    console.log("resflag", resflag);

    if (resflag) {
      toast.success("product added successfully", {
        position: "top-right",
        duration: 3000,
      });
    } else {
      toast.error("something went wrong", {
        position: "top-right",
        duration: 3000,
      });
    }
  }
  // const [isSearching, setisSearching] = useState(false);
  const [searchedData, setsearchedData] = useState("");
  const { numOfCartitems, addproductTocart, setnumOfCartitems } =
    useContext(cartContextt);
  ////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////
  const [heartcolor, setheartcolor] = useState(false);
  const { addProductToWishList } = useContext(wishlistcontext);

  ////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  async function handleaddproductTowishlist(id) {
    setheartcolor(true);
    const resflag = await addProductToWishList(id);
    console.log("resflag", resflag);

    if (resflag) {
      toast.success("product added successfully to wish list", {
        position: "top-right",
        duration: 3000,
      });
    } else {
      toast.error("something went wrong", {
        position: "top-right",
        duration: 3000,
      });
    }
  }
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////

  const productsearch = useFormik({
    initialValues: {
      searchvalue: "",
    },
    onSubmit: async (values) => {
      const { data } = await axios.get(
        "https://ecommerce.routemisr.com/api/v1/products"
      );

      const filterdData = data.data.filter((product) => {
        // console.log("values", values, "title_before_check", product.title);
        if (product.title.includes(values.searchvalue)) {
          // console.log("values:", values, "title_after_check:", product.title);
          // setsearchedData(filterdData);
          // console.log(searchedData);
          return product;
        }
      });
      console.log(filterdData);

      setsearchedData(filterdData);
      // console.log(searchedData);
    },
  });

  function getAllProducts() {
    return axios.get("https://ecommerce.routemisr.com/api/v1/products");
  }

  const { data, isError, isLoading } = useQuery({
    queryKey: ["allproducts", 2],
    queryFn: getAllProducts,
    refetchOnWindowFocus: true,
    staleTime: 3600 * 1000,
  });

  if (isLoading) {
    return (
      <>
        <div className=" flex justify-center items-center h-screen">
          <Bars
            height="80"
            width="80"
            color="#4fa94d"
            ariaLabel="bars-loading"
            wrapperStyle={{}}
            wrapperClass=""
            visible={true}
          />
        </div>
      </>
    );
  }
  if (isError) {
    <h2>error</h2>;
  }

  return (
    <>
      <div className="flex justify-center items-center">
        <div className=" w-[80%]">
          <SimpleSlider />
        </div>
        <div className="w-[20%]">
          <img src={sliderimg1} className=" w-full h-[287px]" alt="" />
          <img src={sliderimg2} className=" w-full h-[287px]" alt="" />
        </div>
      </div>
      <Categories />

      <div className="input flex justify-center container   mx-auto mt-[50px]">
        <form
          action=""
          className="w-3/4"
          onChange={productsearch.handleSubmit}
          onSubmit={productsearch.handleSubmit}
        >
          <input
            type="search"
            name="searchvalue"
            onChange={productsearch.handleChange}
            onBlur={productsearch.handleBlur}
            className=" border-2 w-full  border-gray-300  rounded-md p-2  "
            placeholder="search"
          />
        </form>
      </div>
      <div className=" grid md:grid-cols-3 lg:grid-cols-4 container mx-auto mt-[50px]  ">
        {searchedData ? (
          <>
            {searchedData.map((product) => (
              <Card product={product} key={product._id} />
            ))}
          </>
        ) : (
          <>
            {data.data.data.map((product) => (
              <Card product={product} key={product._id} />
            ))}
          </>
        )}
      </div>
    </>
  );
}
