export default function Notfound() {
  return <div>Notfound</div>;
}
