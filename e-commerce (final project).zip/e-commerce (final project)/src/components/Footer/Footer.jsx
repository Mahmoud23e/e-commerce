export default function Footer() {
  return (
    <>
      <div className="footer bg-slate-600 text-white"></div>
    </>
  );
}
