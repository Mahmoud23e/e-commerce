import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import sliderimage1 from "../../assets/finalProject assets/images/slider-image-1.jpeg";
import sliderimage2 from "../../assets/finalProject assets/images/slider-image-2.jpeg";
import sliderimage3 from "../../assets/finalProject assets/images/slider-image-3.jpeg";
import sliderimage4 from "../../assets/finalProject assets/images/slider-2.jpeg";
import sliderimage5 from "../../assets/finalProject assets/images/grocery-banner-2.jpeg";
import sliderimage6 from "../../assets/finalProject assets/images/grocery-banner.png";

export default function SimpleSlider() {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    autoplay: true,
  };
  return (
    <Slider {...settings} className="mt-[79px] cursor-grab ">
      <div>
        <img src={sliderimage1} className="  h-[500px]  w-full" alt="" />
      </div>
      <div>
        <img src={sliderimage2} className="  h-[500px]  w-full" alt="" />
      </div>
      <div>
        <img src={sliderimage3} className="  h-[500px]  w-full" alt="" />
      </div>
      <div>
        <img src={sliderimage4} className="  h-[500px]  w-full" alt="" />
      </div>
      <div>
        <img src={sliderimage5} className="   h-[500px] w-full" alt="" />
      </div>
      <div>
        <img src={sliderimage6} className="  h-[500px]  w-full" alt="" />
      </div>
    </Slider>
  );
}
