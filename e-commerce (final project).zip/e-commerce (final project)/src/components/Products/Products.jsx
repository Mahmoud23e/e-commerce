import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { useEffect, useState } from "react";
import { Bars } from "react-loader-spinner";
import Card from "../card/Card";

export default function Products() {
  function getAllProducts() {
    return axios.get("https://ecommerce.routemisr.com/api/v1/products");
  }

  const [query, setquery] = useState("");
  const [filterddata, setfilterddata] = useState([]);

  useEffect(() => {
    async function getdata() {
      const { data } = await axios.get(
        "https://ecommerce.routemisr.com/api/v1/products"
      );

      const alldata = await data.data;

      const filteredproduct = alldata.filter((product) => {
        if (product.title.includes(query)) {
          return product;
        }
      });
      setfilterddata(filteredproduct);
    }
    getdata();
  }, [query]);

  console.log(filterddata);

  const { data, isError, isLoading } = useQuery({
    queryKey: "allproducts",
    queryFn: getAllProducts,
    staleTime: 3600 * 1000,
  });

  if (isLoading) {
    return (
      <>
        <div className=" flex justify-center items-center h-screen">
          <Bars
            height="80"
            width="80"
            color="#4fa94d"
            ariaLabel="bars-loading"
            wrapperStyle={{}}
            wrapperClass=""
            visible={true}
          />
        </div>
        ;
      </>
    );
  }
  if (isError) {
    return (
      <>
        <h1>error;</h1>
      </>
    );
  }

  function handleSubmit(e) {
    e.preventDefault();
  }
  return (
    <>
      <form
        action=""
        onSubmit={handleSubmit}
        // onSubmit={productsearch.handleSubmit}
        // onChange={productsearch.handleSubmit}
      >
        <div className="input flex justify-center container   mx-auto mt-[150px]">
          <input
            type="search"
            name="searchvalue"
            className=" border-2    w-3/4 border-gray-300  rounded-md p-2  "
            placeholder="search"
            value={query}
            onChange={(e) => setquery(e.target.value)}
            // onBlur={productsearch.handleBlur}
          />
        </div>
      </form>
      <div className=" grid  md:grid-cols-3 lg:grid-cols-4 container mx-auto mt-[50px]  ">
        {filterddata
          ? filterddata.map((product) => (
              <Card product={product} key={product._id} />
            ))
          : data.data.data.map((product) => (
              <Card product={product} key={product._id} />
            ))}
      </div>
    </>
  );
}
