import axios from "axios";
import { useFormik } from "formik";
import { useContext, useState } from "react";
import { ColorRing } from "react-loader-spinner";
import { Link, useNavigate } from "react-router-dom";
import * as yup from "yup";
import { authcontext } from "../../Context/AuthContext";

export default function Login() {
  const { settoken } = useContext(authcontext);

  const navigat = useNavigate();
  const [iserror, setiserror] = useState(null);
  const [isloading, setisloading] = useState(false);
  const [isSuccess, setisSuccess] = useState(false);

  const registerformik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    onSubmit: (values) => {
      setisloading(true);
      axios
        .post("https://ecommerce.routemisr.com/api/v1/auth/signin", values)
        .then(function (data) {
          localStorage.setItem("tkn", data.data.token);
          settoken(data.data.token);
          console.log("sa7", data.data.token);
          setisSuccess(true);

          setTimeout(() => {
            navigat("/products");
          }, 1000);

          setisloading(false);
        })
        .catch(function (error) {
          console.log("8lat", error.response.data.message);
          setiserror(error.response.data.message);
          setisloading(false);
          setTimeout(() => {
            setiserror(null);
          }, 2000);
        });

      console.log(values);
    },
    validationSchema: yup.object().shape({
      email: yup
        .string()
        .required("email is required")
        .matches(
          /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
          "please enter a valid email"
        ),
      password: yup
        .string()
        .required("password is required")
        .matches(
          /^(?=.*[a-z])(?=.*[A-Z]).{8,32}$/,
          "password must contain upper and lower case letters and must be between 8 nad 32 characters "
        ),
    }),
  });
  return (
    <>
      <form
        onSubmit={registerformik.handleSubmit}
        className=" container mx-auto p-4 text-black mt-20  "
      >
        <p className=" font-semibold text-[30px] mb-4">Login now</p>

        <div className="relative z-0 w-full mb-5 group">
          <input
            type="email"
            name="email"
            onBlur={registerformik.handleBlur}
            onChange={registerformik.handleChange}
            value={registerformik.values.email}
            id="email"
            className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-black dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
            placeholder=" "
            required
          />
          <label
            htmlFor="email"
            className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
          >
            Email:
          </label>
        </div>
        {registerformik.errors.email && registerformik.touched.email ? (
          <div
            className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-red-400 text-white"
            role="alert"
          >
            <svg
              className="flex-shrink-0 inline w-4 h-4 me-3"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
            </svg>
            <span className="sr-only">Info</span>
            <div>{registerformik.errors.email}</div>
          </div>
        ) : (
          ""
        )}

        <div className="relative z-0 w-full mb-5 group">
          <input
            type="password"
            name="password"
            onBlur={registerformik.handleBlur}
            onChange={registerformik.handleChange}
            value={registerformik.values.password}
            id="password"
            className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-black dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
            placeholder=" "
            required
          />
          <label
            htmlFor="floating_repeat_password"
            className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
          >
            Password:
          </label>
        </div>
        {registerformik.errors.password && registerformik.touched.password ? (
          <div
            className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-red-400 text-white"
            role="alert"
          >
            <svg
              className="flex-shrink-0 inline w-4 h-4 me-3"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
            </svg>
            <span className="sr-only">Info</span>
            <div>{registerformik.errors.password}</div>
          </div>
        ) : (
          ""
        )}

        {iserror ? (
          <div
            className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-red-400 text-white"
            role="alert"
          >
            <svg
              className="flex-shrink-0 inline w-4 h-4 me-3"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
            </svg>
            <span className="sr-only">Info</span>
            <div>{iserror}</div>
          </div>
        ) : (
          ""
        )}
        {isSuccess ? (
          <div
            className="flex items-center p-4 mb-4 text-sm  rounded-lg bg-red-50 dark:bg-green-400 text-white"
            role="alert"
          >
            <svg
              className="flex-shrink-0 inline w-4 h-4 me-3"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
            </svg>
            <span className="sr-only">Info</span>
            <div>welcome</div>
          </div>
        ) : (
          ""
        )}

        <button
          type="submit"
          className=" flex items-center text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto  px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
        >
          {isloading ? (
            <ColorRing
              visible={true}
              height="30"
              width="30"
              ariaLabel="color-ring-loading"
              wrapperStyle={{}}
              wrapperClass="color-ring-wrapper"
              colors={["#fff", "#fff", "#fff", "#fff", "#fff"]}
            />
          ) : (
            " Login now"
          )}
        </button>
      </form>

      <div className=" container mx-auto p-4 flex ">
        <Link to="/forgetpassword">
          <p className=" hover:text-green-500 transition duration-300 cursor-pointer  font-bold text-[20px]">
            Forget your Password?
          </p>
        </Link>
      </div>
    </>
  );
}
