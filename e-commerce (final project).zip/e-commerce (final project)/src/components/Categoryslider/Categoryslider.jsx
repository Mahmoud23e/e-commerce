import { Bars } from "react-loader-spinner";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import UseCategories from "../../Customhooks/UseCategories/UseCategories";

export default function Categories() {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 10,
    slidesToScroll: 5,
    arrows: false,
    autoplay: true,
  };
  const { data, isError, isLoading } = UseCategories();

  if (isError) {
    return (
      <>
        <div className=" h-screen bg-gray-700 flex justify-center items-center  ">
          <h2 className=" text-white text-[100px] font-bold">error</h2>
        </div>
      </>
    );
  }
  if (isLoading) {
    return (
      <>
        <div className=" flex justify-center items-center h-[500px]">
          <Bars
            height="80"
            width="80"
            color="#4fa94d"
            ariaLabel="bars-loading"
            wrapperStyle={{}}
            wrapperClass=""
            visible={true}
          />
        </div>
      </>
    );
  }

  return (
    <>
      <Slider {...settings} dots className="mt-[40px] cursor-grab  ">
        {data.data.data.map((category) => (
          <>
            <div>
              <img src={category.image} className="h-[300px] w-full" alt="" />
              <p>{category.name}</p>
            </div>
          </>
        ))}
      </Slider>
    </>
  );
}
