import { useQuery } from "@tanstack/react-query";
import axios from "axios";

export default function UseCategories() {
  function getAllCategories() {
    return axios.get("https://ecommerce.routemisr.com/api/v1/categories");
  }

  const UseQueryRes = useQuery({
    queryKey: "getAllCategories",
    queryFn: getAllCategories,
  });

  return UseQueryRes;
}
