import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "./components/layout/layout";
import Home from "./components/Home/Home";
import Login from "./components/Login/Login";
import Register from "./components/register/Register";
import Notfound from "./components/Notfound/Notfound";
import Products from "./components/Products/Products";
import Brands from "./components/Brands/Brands";
import AuthContext from "./Context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute/ProtectedRoute";
import WishList from "./components/WishList/WishList";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Categories from "./components/Categories/Categories";
import Productdetails from "./components/Productdetails/Productdetails";
import CartContext from "./Context/CartContext";
import { Toaster } from "react-hot-toast";
import Cart from "./components/Cart/Cart";
import Wishlistcontext from "./Context/wishlistcontext";
import Payment from "./components/payment/payment";
import Allorders from "./components/Allorders/Allorders";
import ForgetPassword from "./forgetPassword/ForgetPassword";
import Verification from "./components/verification/Verification";
import Resetpassword from "./components/resetPassword/Resetpassword";

export default function App() {
  const reactqueryconfig = new QueryClient();
  const router = createBrowserRouter([
    {
      path: "",
      element: <Layout />,
      children: [
        {
          path: "",
          element: (
            <ProtectedRoute>
              <Home />
            </ProtectedRoute>
          ),
        },
        {
          path: "login",
          element: <Login />,
        },
        {
          path: "wishlist",
          element: (
            <ProtectedRoute>
              <WishList />
            </ProtectedRoute>
          ),
        },
        {
          path: "payment",

          element: (
            <ProtectedRoute>
              <Payment />
            </ProtectedRoute>
          ),
        },
        {
          path: "register",
          element: <Register />,
        },
        {
          path: "verification",
          element: <Verification />,
        },
        {
          path: "forgetpassword",
          element: <ForgetPassword />,
        },
        {
          path: "resetPassword",
          element: <Resetpassword />,
        },
        {
          path: "ProductDetails/:id",
          element: (
            <ProtectedRoute>
              <Productdetails />
            </ProtectedRoute>
          ),
        },
        {
          path: "products",

          element: (
            <ProtectedRoute>
              <Products />
            </ProtectedRoute>
          ),
        },
        {
          path: "cart",

          element: (
            <ProtectedRoute>
              <Cart />
            </ProtectedRoute>
          ),
        },
        {
          path: "brands",
          element: (
            <ProtectedRoute>
              <Brands />,
            </ProtectedRoute>
          ),
        },
        {
          path: "allorders",
          element: (
            <ProtectedRoute>
              <Allorders />,
            </ProtectedRoute>
          ),
        },
        {
          path: "categories",
          element: (
            <ProtectedRoute>
              <Categories />,
            </ProtectedRoute>
          ),
        },
        {
          path: "*",
          element: <Notfound />,
        },
      ],
    },
  ]);
  return (
    <AuthContext>
      <CartContext>
        <Wishlistcontext>
          <QueryClientProvider client={reactqueryconfig}>
            <RouterProvider router={router} />
            <Toaster />
          </QueryClientProvider>
        </Wishlistcontext>
      </CartContext>
    </AuthContext>
  );
}
