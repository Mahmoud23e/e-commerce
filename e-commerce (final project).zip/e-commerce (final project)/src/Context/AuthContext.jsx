import { createContext, useState } from "react";

export const authcontext = createContext();

export default function AuthContext({ children }) {
  const [token, settoken] = useState(localStorage.getItem("tkn"));
  console.log(token);

  return (
    <authcontext.Provider value={{ token, settoken }}>
      {children}
    </authcontext.Provider>
  );
}
