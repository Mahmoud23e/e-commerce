import axios from "axios";
import { createContext, useState } from "react";

export const wishlistcontext = createContext();

export default function Wishlistcontext({ children }) {
  const [isadding, setisadding] = useState(false);
  const [isloading, setisloading] = useState(false);

  const [allwishlistproducts, setallwishlistproducts] = useState(null);

  async function addProductToWishList(productId) {
    setisadding(true);
    return axios
      .post(
        "https://ecommerce.routemisr.com/api/v1/wishlist",
        {
          productId: productId,
        },
        {
          headers: {
            token: localStorage.getItem("tkn"),
          },
        }
      )
      .then((res) => {
        console.log(res);
        setisadding(false);
        return true;
      })
      .catch((error) => {
        console.log(error);
        return false;
      });
  }

  function getwishlistproducts() {
    setisloading(true);
    axios
      .get("https://ecommerce.routemisr.com/api/v1/wishlist", {
        headers: {
          token: localStorage.getItem("tkn"),
        },
      })
      .then((res) => {
        setisloading(false);
        setallwishlistproducts(res.data.data);
        console.log(res.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  async function deletewishlistproduct(id) {
    setisloading(true);
    return axios
      .delete(`https://ecommerce.routemisr.com/api/v1/wishlist/${id}`, {
        headers: {
          token: localStorage.getItem("tkn"),
        },
      })
      .then(() => {
        setisloading(false);
        getwishlistproducts();
        return true;
      })
      .catch((error) => {
        console.log(error);
        return false;
      });
  }

  return (
    <>
      <wishlistcontext.Provider
        value={{
          addProductToWishList,
          isadding,
          allwishlistproducts,
          getwishlistproducts,
          deletewishlistproduct,
          isloading,
        }}
      >
        {children}
      </wishlistcontext.Provider>
    </>
  );
}
