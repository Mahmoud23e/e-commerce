import axios from "axios";
import { createContext, useEffect, useState } from "react";
// import toast from "react-hot-toast";

export const cartContextt = createContext();

export default function CartContext({ children }) {
  const [allproducts, setallproducts] = useState(null);
  const [numOfCartitems, setnumOfCartitems] = useState(0);
  const [totalcartprics, settotalcartprics] = useState(0);
  const [isloading, setisloading] = useState(false);
  const [cartidforpayment, setcartidforpayment] = useState(null);

  /////////display cart products/////////////////////
  //   async function getcartproducts() {
  //     await axios
  //       .get("https://ecommerce.routemisr.com/api/v1/cart", {
  //         headers: {
  //           token: localStorage.getItem("tkn"),
  //         },
  //       })
  //       .then((res) => {
  //         setnumOfCartitems(res.data.numOfCartItems);
  //       });
  //   }
  ////////////////////////////////////////////

  async function addproductTocart(productId) {
    return axios
      .post(
        "https://ecommerce.routemisr.com/api/v1/cart",
        {
          productId: productId,
        },
        {
          headers: {
            token: localStorage.getItem("tkn"),
          },
        }
      )
      .then((res) => {
        setallproducts(res.data.data.products);
        setnumOfCartitems(res.data.numOfCartItems);
        settotalcartprics(res.data.data.totalCartPrice);
        return true;
      })
      .catch((error) => {
        console.log(error);
        return false;
      });
  }

  async function updatecount(product_id, newcount) {
    setisloading(true);
    axios
      .put(
        `https://ecommerce.routemisr.com/api/v1/cart/${product_id}`,
        {
          count: newcount,
        },
        {
          headers: {
            token: localStorage.getItem("tkn"),
          },
        }
      )
      .then((res) => {
        setallproducts(res.data.data.products);
        setnumOfCartitems(res.data.numOfCartItems);
        settotalcartprics(res.data.data.totalCartPrice);
        setisloading(false);
      })
      .catch((error) => {
        console.log(error);
      });
  }
  //   if (isloading) {
  //     return (
  //       <>
  //         <div className=" flex justify-center items-center h-screen">
  //           <Bars
  //             height="80"
  //             width="80"
  //             color="#4fa94d"
  //             ariaLabel="bars-loading"
  //             wrapperStyle={{}}
  //             wrapperClass=""
  //             visible={true}
  //           />
  //         </div>
  //         ;
  //       </>
  //     );
  //   }

  function getcartproducts() {
    setisloading(true);
    axios
      .get("https://ecommerce.routemisr.com/api/v1/cart", {
        headers: {
          token: localStorage.getItem("tkn"),
        },
      })
      .then((res) => {
        setallproducts(res.data.data.products);
        setnumOfCartitems(res.data.numOfCartItems);
        settotalcartprics(res.data.data.totalCartPrice);
        setisloading(false);
        setcartidforpayment(res.data.data._id);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  async function deleteproduct(id) {
    setisloading(true);
    return axios
      .delete(`https://ecommerce.routemisr.com/api/v1/cart/${id}`, {
        headers: {
          token: localStorage.getItem("tkn"),
        },
      })
      .then((res) => {
        setallproducts(res.data.data.products);
        setnumOfCartitems(res.data.numOfCartItems);
        settotalcartprics(res.data.data.totalCartPrice);
        setisloading(false);
        return true;
      })
      .catch((error) => {
        console.log(error);
        return false;
      });
  }

  function clearcart() {
    setisloading(true);

    axios
      .delete(`https://ecommerce.routemisr.com/api/v1/cart`, {
        headers: {
          token: localStorage.getItem("tkn"),
        },
      })
      .then(() => {
        setallproducts(null);
        setnumOfCartitems(0);
        settotalcartprics(0);
        setisloading(false);
      });
  }

  useEffect(() => {
    getcartproducts();
  }, []);

  return (
    <>
      <cartContextt.Provider
        value={{
          numOfCartitems,
          allproducts,
          totalcartprics,
          isloading,
          cartidforpayment,
          addproductTocart,
          setnumOfCartitems,
          updatecount,
          setallproducts,
          settotalcartprics,
          getcartproducts,
          deleteproduct,
          clearcart,
        }}
      >
        {children}
      </cartContextt.Provider>
    </>
  );
}
